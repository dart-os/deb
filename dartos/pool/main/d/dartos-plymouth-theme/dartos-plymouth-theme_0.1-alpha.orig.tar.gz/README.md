# Official Dart OS Plymouth Theme
Dart OS dev <sys41x4@zohomail.in>
---
dartos-plymouth-theme pkg source repo : https://gitlab.com/dart-os/packages/dartos-plymouth-theme.git
---

Copyright (C) 2023 Arijit Bhowmick <cybersec.arijitbhowmick@gmail.com> <br>
License: GPL-3.0+ <br>
Author: Arijit Bhowmick <br>
Dependency: plymouth <br>

---

<h6>BRANCH: <br>
<a href="https://gitlab.com/dart-os/packages/dartos-plymouth-theme/-/tree/main">MAIN</a> <br>
<a href="https://gitlab.com/dart-os/packages/dartos-plymouth-theme/-/tree/stable">STABLE</a> <br>
<a href="https://gitlab.com/dart-os/packages/dartos-plymouth-theme/-/tree/beta">BETA</a> <br>
<a href="https://gitlab.com/dart-os/packages/dartos-plymouth-theme/-/tree/alpha">ALPHA</a> <br>
<a href="https://gitlab.com/dart-os/packages/dartos-plymouth-theme/-/tree/dev">DEV</a> <br>
</h6>

<hr>
<p align="center">
Developed with ❤️
</p>
