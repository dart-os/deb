##<font color="#55aa00"><b>dartos-plymouth-theme</b></font>

* __`Version:`__ 1.0
* __`Date:`__ 26.03.2023
* __`License:`__  [GPL-3.0](https://www.gnu.org/licenses/gpl-3.0.txt)
* __`Copyright:`__ Copyright (C) 2023 Arijit Bhowmick <cybersec.arijitbhowmick@gmail.com>
* __`Author:`__ [Arijit Bhowmick](https://sys41x4.github.io/)

---------------------------------

## Package:
dartos-plymouth-theme.deb


---------------------------------
### Changelog:
>
___`v1.0 (26.03.2023)`___
>
* `First release`









