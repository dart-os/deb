# Official Dart OS Wallpapers
Dart OS dev - <sys41x4@zohomail.in>
---
dartos-wallpapers pkg source repo : https://gitlab.com/dart-os/packages/dartos-wallpapers.git
---

Copyright (C) 2023 Arijit Bhowmick <cybersec.arijitbhowmick@gmail.com> <br>
License: GPL-3.0+ <br>
Author: Arijit Bhowmick <br>

---

<h6>BRANCH: <br>
<a href="https://gitlab.com/dart-os/packages/dartos-wallpapers/-/tree/main">MAIN</a> <br>
<a href="https://gitlab.com/dart-os/packages/dartos-wallpapers/-/tree/stable">STABLE</a> <br>
<a href="https://gitlab.com/dart-os/packages/dartos-wallpapers/-/tree/beta">BETA</a> <br>
<a href="https://gitlab.com/dart-os/packages/dartos-wallpapers/-/tree/alpha">ALPHA</a> <br>
<a href="https://gitlab.com/dart-os/packages/dartos-wallpapers/-/tree/dev">DEV</a> <br>
</h6>

<hr>
<p align="center">
Developed with ❤️
</p>
